# Como adicionar mais projetos à galeria


Todos os projetos ficam em **um único arquivo: `js/portfolio-data.js`**
(lista `window.showcase`). Ele alimenta os dois lugares do site ao mesmo
tempo: os **carrosséis infinitos** da home e a página **`projetos.html`**
(grade separada por tipo). A seção "Projetos em Destaque" da home é
independente, com blocos HTML fixos (ver passo 5).

**Para adicionar um novo projeto:**

1. Coloque o arquivo de imagem em `assets/portfolio/` (de preferência
   JPG com até ~1080 px de largura).
2. Abra `js/portfolio-data.js` e copie uma linha existente, ajustando:

   ```js
   { type: 'Designer', cat: 'Logotipos', title: 'Novo Projeto',
     desc: 'Descrição curta.',
     color: 'linear-gradient(150deg,#241414,#1c1e25)',
     img: 'assets/portfolio/novo-projeto.webp' }
   ```

   - `type` define a seção na página de projetos:
     `'Designer'`, `'Social Media'` ou `'Web'`.
   - `cat` é a etiqueta pequena do card (Logotipos, Mockups, Ilustrações...).
   - Site ao vivo (sem imagem): use `url: 'https://exemplo.com'` no lugar de `img`.
3. **Logotipo** ou arte que deve aparecer inteira (sem cortar): adicione
   `fit: 'contain'`.
4. **Arte vertical** (story 9/16, post 4/5): adicione `ratio: '9/16'` ou
   `ratio: '4/5'` para o Lightbox não cortar a imagem.
5. **Carrossel de vários slides**: adicione `slides: [...]` com a lista
   de imagens (a primeira também vai em `img`). O card ganha o selo
   "N slides" e o Lightbox permite navegar pelos slides (setas, teclas
   ← → ou deslizando no celular).

   ```js
   { type: 'Social Media', cat: 'Social Media', title: 'Meu carrossel',
     desc: '...', color: '...', ratio: '4/5',
     img: 'assets/portfolio/slide-01.webp',
     slides: ['assets/portfolio/slide-01.webp', 'assets/portfolio/slide-02.webp'] }
   ```

6. Para aparecer também em "Projetos em Destaque" (cards sobrepostos no
   topo), copie um bloco `<article class="stack-card-sticky feature-card">`
   no `index.html` — essa seção é escrita à mão.

> No Spck Editor: abra `js/portfolio-data.js` e use a busca por
> `window.showcase`. Novos projetos entram nas duas fileiras do carrossel
> automaticamente (posições pares na primeira, ímpares na segunda).

