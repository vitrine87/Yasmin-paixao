-- =====================================================================
-- Yasmin Paixão — esquema do Supabase para solicitações de orçamento
-- Rode este arquivo inteiro no SQL Editor do Supabase (pode rodar de novo
-- sem problema: ele é idempotente).
--
-- Modelo de segurança:
--   * O visitante (anon) NÃO lê nem escreve direto na tabela. Ele só
--     consegue chamar duas funções:
--       - create_quote_request  → cria a solicitação e devolve o código
--       - consult_quote_request → consulta exigindo nome + telefone + código
--   * Só quem estiver na tabela "admins" consegue listar/atualizar as
--     solicitações (via RLS) — base para o futuro painel /admin.
--   * Limite de tentativas por IP nas duas funções (best-effort).
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Tabelas
-- ---------------------------------------------------------------------
create table if not exists public.quote_requests (
  id            uuid primary key default gen_random_uuid(),
  name          text not null check (char_length(name) between 2 and 120),
  phone         text not null check (char_length(phone) between 10 and 20),
  phone_digits  text generated always as (regexp_replace(phone, '\D', '', 'g')) stored,
  service       text not null check (service in (
                  'Logotipo','Ilustração Digital','Personagem','Mockup',
                  'Identidade Visual','Projeto de Jogo','Post para Redes Sociais',
                  'Panfleto','Banner','Outro')),
  message       text not null check (char_length(message) between 5 and 2000),
  tracking_code text not null unique,
  status        text not null default 'pending'
                  check (status in ('pending','confirmed','refused')),
  admin_message text not null default '' check (char_length(admin_message) <= 1000),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create index if not exists quote_requests_created_idx
  on public.quote_requests (created_at desc);

-- Quem é administrador (cadastre o user_id depois de criar a conta dela).
create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);

-- Controle de limite de tentativas por IP.
create table if not exists public.rate_limits (
  id         bigint generated always as identity primary key,
  bucket     text not null,
  client     text not null,
  created_at timestamptz not null default now()
);
create index if not exists rate_limits_lookup_idx
  on public.rate_limits (bucket, client, created_at desc);
create index if not exists rate_limits_created_idx
  on public.rate_limits (created_at);

-- ---------------------------------------------------------------------
-- 2. RLS + permissões das tabelas
-- ---------------------------------------------------------------------
alter table public.quote_requests enable row level security;
alter table public.admins         enable row level security;
alter table public.rate_limits    enable row level security;

revoke all on public.quote_requests from anon, authenticated;
revoke all on public.admins         from anon, authenticated;
revoke all on public.rate_limits    from anon, authenticated;

grant select on public.quote_requests to authenticated;
grant update (status, admin_message) on public.quote_requests to authenticated; -- admin não altera código/telefone

-- função auxiliar: o usuário logado é admin?
create or replace function public.is_admin()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;
revoke execute on function public.is_admin() from public, anon;
grant  execute on function public.is_admin() to authenticated;

drop policy if exists "Admin lê solicitações"       on public.quote_requests;
drop policy if exists "Admin atualiza solicitações" on public.quote_requests;
drop policy if exists "Admin exclui solicitações" on public.quote_requests;

-- exige MFA (aal2): o painel admin.html cuida do cadastro do autenticador
create policy "Admin lê solicitações"
  on public.quote_requests for select to authenticated
  using (public.is_admin() and coalesce(auth.jwt() ->> 'aal', '') = 'aal2');

create policy "Admin atualiza solicitações"
  on public.quote_requests for update to authenticated
  using (public.is_admin() and coalesce(auth.jwt() ->> 'aal', '') = 'aal2')
  with check (public.is_admin() and coalesce(auth.jwt() ->> 'aal', '') = 'aal2');

drop policy if exists "Admin exclui solicitações" on public.quote_requests;
create policy "Admin exclui solicitações"
  on public.quote_requests for delete to authenticated
  using (public.is_admin() and coalesce(auth.jwt() ->> 'aal', '') = 'aal2');
grant delete on public.quote_requests to authenticated;

-- Retenção (LGPD): ative a extensão pg_cron (Database → Extensions) e descomente:
-- select cron.schedule('yp-retencao-orcamentos', '0 3 * * 0',
--   $$delete from public.quote_requests where created_at < now() - interval '12 months'$$);

-- mantém updated_at correto
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

drop trigger if exists quote_requests_touch on public.quote_requests;
create trigger quote_requests_touch
  before update on public.quote_requests
  for each row execute function public.touch_updated_at();

-- ---------------------------------------------------------------------
-- 3. Limite de tentativas por IP
-- ---------------------------------------------------------------------
create or replace function public.client_ip()
returns text
language plpgsql stable
as $$
declare v_ip text;
begin
  -- só confia em cf-connecting-ip (definido pela borda, não forjável); sem ele, recusa.
  v_ip := nullif(btrim(nullif(current_setting('request.headers', true), '')::json ->> 'cf-connecting-ip'), '');
  if v_ip is null then raise exception 'rate_limited'; end if;
  -- IPv6: agrupa pelo prefixo /64 (evita rotação de IP dentro do mesmo bloco)
  if position(':' in v_ip) > 0 then
    v_ip := host(network(set_masklen(v_ip::inet, 64)));
  end if;
  return v_ip;
end $$;

create or replace function public.enforce_rate_limit(p_bucket text, p_max int, p_window interval)
returns void
language plpgsql security definer
set search_path = public
as $$
declare
  v_client text := public.client_ip();
  v_count  int;
begin
  perform pg_advisory_xact_lock(hashtext(p_bucket || v_client)); -- evita corrida entre requisições simultâneas
  delete from public.rate_limits where created_at < now() - interval '1 day';

  select count(*) into v_count
    from public.rate_limits
   where bucket = p_bucket and client = v_client
     and created_at > now() - p_window;

  if v_count >= p_max then
    raise exception 'rate_limited';
  end if;

  insert into public.rate_limits (bucket, client) values (p_bucket, v_client);
end $$;
revoke execute on function public.enforce_rate_limit(text, int, interval) from public, anon, authenticated;

-- ---------------------------------------------------------------------
-- 4. Funções públicas (as únicas portas de entrada do visitante)
-- ---------------------------------------------------------------------
create or replace function public.create_quote_request(
  p_name text, p_phone text, p_service text, p_message text
) returns text
language plpgsql security definer
set search_path = public
as $$
declare
  v_alphabet constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  v_code text;
  v_try  int := 0;
begin
  p_name    := btrim(coalesce(p_name, ''));
  p_phone   := btrim(coalesce(p_phone, ''));
  p_service := btrim(coalesce(p_service, ''));
  p_message := btrim(coalesce(p_message, ''));

  if char_length(p_name) not between 2 and 120
     or char_length(regexp_replace(p_phone, '\D', '', 'g')) not between 10 and 13
     or char_length(p_message) not between 5 and 2000
     or p_service not in ('Logotipo','Ilustração Digital','Personagem','Mockup',
                          'Identidade Visual','Projeto de Jogo','Post para Redes Sociais',
                          'Panfleto','Banner','Outro') then
    raise exception 'invalid_input';
  end if;

  perform public.enforce_rate_limit('create', 5, interval '1 hour');

  loop
    v_code := 'YP-' || (
      select string_agg(substr(v_alphabet, 1 + (get_byte(b, i) % 32), 1), '')
        from (select uuid_send(gen_random_uuid()) as b) s, generate_series(0, 5) as i  -- CSPRNG, sem viés (256 % 32 = 0)
    );
    begin
      insert into public.quote_requests (name, phone, service, message, tracking_code)
      values (p_name, p_phone, p_service, p_message, v_code);
      return v_code;
    exception when unique_violation then
      v_try := v_try + 1;
      if v_try >= 5 then raise exception 'try_again'; end if;
    end;
  end loop;
end $$;

create or replace function public.norm_name(t text)
returns text language sql immutable as $$
  select translate(lower(regexp_replace(btrim(coalesce(t, '')), '\s+', ' ', 'g')),
                   'áàâãäéèêëíìîïóòôõöúùûüç', 'aaaaaeeeeiiiiooooouuuuc');
$$;

create or replace function public.consult_quote_request(
  p_name text, p_phone text, p_tracking_code text
) returns jsonb
language plpgsql security definer
set search_path = public
as $$
declare
  v_result jsonb;
begin
  perform public.enforce_rate_limit('consult', 10, interval '10 minutes');

  select jsonb_build_object(
           'status',        q.status,
           'admin_message', q.admin_message,
           'created_at',    q.created_at,
           'service',       q.service)
    into v_result
    from public.quote_requests q
   where q.tracking_code = upper(btrim(coalesce(p_tracking_code, '')))
     and q.phone_digits  = regexp_replace(coalesce(p_phone, ''), '\D', '', 'g')
     and public.norm_name(q.name) = public.norm_name(p_name);

  return v_result;  -- null quando não encontra (mensagem genérica no front)
end $$;

revoke execute on function public.create_quote_request(text, text, text, text)  from public;
revoke execute on function public.consult_quote_request(text, text, text)       from public;
grant  execute on function public.create_quote_request(text, text, text, text)  to anon, authenticated;
grant  execute on function public.consult_quote_request(text, text, text)       to anon, authenticated;

-- ---------------------------------------------------------------------
-- 5. Depois de criar a conta da Yasmin (login normal no site), torne-a admin:
--
--   insert into public.admins (user_id)
--   select id from auth.users
--   where email = 'EMAIL-DA-YASMIN@exemplo.com' and email_confirmed_at is not null;
-- ---------------------------------------------------------------------
