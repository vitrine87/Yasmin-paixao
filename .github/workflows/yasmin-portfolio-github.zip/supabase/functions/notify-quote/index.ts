// Edge Function: avisa a Yasmin por e-mail a cada novo pedido (Database Webhook em quote_requests, evento INSERT).
// Segredos: supabase secrets set RESEND_API_KEY=... NOTIFY_EMAIL=... FROM_EMAIL=... WEBHOOK_SECRET=...
const esc = (s: unknown) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));

Deno.serve(async (req) => {
  if (req.headers.get("x-webhook-secret") !== Deno.env.get("WEBHOOK_SECRET")) return new Response("forbidden", { status: 403 });
  const { record: r } = await req.json();
  if (!r) return new Response("ok");
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${Deno.env.get("RESEND_API_KEY")}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: Deno.env.get("FROM_EMAIL"),
      to: Deno.env.get("NOTIFY_EMAIL"),
      subject: `Novo pedido ${r.tracking_code} — ${r.service}`,
      html: `<p><b>${esc(r.name)}</b> — ${esc(r.phone)}</p><p>${esc(r.service)}</p><p style="white-space:pre-wrap">${esc(r.message)}</p>`,
    }),
  });
  return new Response(res.ok ? "sent" : "mail error", { status: res.ok ? 200 : 502 });
});
