# Versões vendorizadas
- GSAP / ScrollTrigger 3.15.0
- @supabase/supabase-js 2.117.2 (js/vendor/supabase.js)
