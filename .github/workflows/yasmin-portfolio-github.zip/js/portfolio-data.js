/**
 * Dados do portfólio — fonte única usada pela home (carrosséis infinitos)
 * e pela página projetos.html (grade por tipo).
 *
 * Campos de cada projeto:
 *   type   → grupo da página de projetos: 'Designer' | 'Social Media' | 'Web'
 *   cat    → subcategoria exibida no card (Logotipos, Mockups, Ilustrações...)
 *   title, desc
 *   img    → imagem principal (ou use "url" para um site publicado)
 *   slides → (opcional) lista de imagens para carrosséis de vários slides;
 *            o card mostra a primeira e o lightbox deixa navegar entre elas
 *   ratio  → (opcional) proporção da arte, ex.: '4/5' ou '9/16' — o lightbox
 *            usa para não cortar posts verticais
 *   fit    → 'contain' para logotipos (mostra inteiro, sem cortar)
 *
 * Para adicionar um projeto novo: coloque a imagem em assets/portfolio/ e
 * acrescente um objeto aqui. Os dois lugares do site atualizam sozinhos.
 */
window.PORTFOLIO_TYPES = ['Designer', 'Social Media', 'Web'];

window.showcase = [
  { type: 'Social Media', cat: 'Social Media', title: 'Culto de Curas & Libertação', desc: 'Arte de divulgação para culto da Assembleia de Deus, com data, horário, endereço e preletor em destaque.', color: 'linear-gradient(150deg,#0e2f55,#1c1e25)', img: 'assets/portfolio/culto-curas-libertacao.webp', ratio: '9/16' },
  { type: 'Social Media', cat: 'Social Media', title: 'Transforme Seguidores em Clientes', desc: 'Peça conceitual sobre como uma marca forte transmite confiança e influencia a decisão de compra.', color: 'linear-gradient(150deg,#2a1f3d,#1c1e25)', img: 'assets/portfolio/transforme-seguidores-clientes.webp', ratio: '4/5' },
  {
    type: 'Social Media', cat: 'Social Media', title: 'Nutrição é Mais que Dieta — Carrossel',
    desc: 'Carrossel educativo de 5 slides sobre alimentação equilibrada, pequenas escolhas, mitos e verdades e hábitos saudáveis.',
    color: 'linear-gradient(150deg,#1d2a1c,#1c1e25)', ratio: '4/5',
    img: 'assets/portfolio/nutricao-01.webp',
    slides: [
      'assets/portfolio/nutricao-01.webp',
      'assets/portfolio/nutricao-02.webp',
      'assets/portfolio/nutricao-03.webp',
      'assets/portfolio/nutricao-04.webp',
      'assets/portfolio/nutricao-05.webp'
    ]
  },
  { type: 'Designer', cat: 'Logotipos', title: 'Nutrição e Saúde — Dra. Natacha Figueiredo', desc: 'Logotipo com formas orgânicas em verde-oliva e verde-escuro para consultório de nutrição.', color: 'linear-gradient(150deg,#22301f,#1c1e25)', img: 'assets/portfolio/natacha-figueiredo-logotipo.webp', fit: 'contain', ratio: '1/1' },

  { type: 'Social Media', cat: 'Social Media', title: 'Halloween Party — Post', desc: 'Arte temática para divulgação de evento sazonal.', color: 'linear-gradient(150deg,#2b2126,#1c1e25)', img: 'assets/portfolio/halloween-party.webp' },
  { type: 'Social Media', cat: 'Social Media', title: 'Tem de Tudo! — Campanha Delivery', desc: 'Campanha de posts para delivery: pizza, burger e combo.', color: 'linear-gradient(150deg,#332430,#1c1e25)', img: 'assets/portfolio/food-social-media.webp' },
  { type: 'Social Media', cat: 'Social Media', title: 'Império Espetos — Cardápio', desc: 'Peça de menu e divulgação para rede de espetos.', color: 'linear-gradient(150deg,#26272f,#1c1e25)', img: 'assets/portfolio/imperio-espetos-cardapio.webp' },
  { type: 'Designer', cat: 'Logotipos', title: 'Império Espetos — Logotipo', desc: 'Identidade visual para hamburgueria/espeteria.', color: 'linear-gradient(150deg,#2a2a24,#1c1e25)', img: 'assets/portfolio/imperio-espetos-logotipo.webp', fit: 'contain' },
  { type: 'Designer', cat: 'Logotipos', title: 'Eloá Representações', desc: 'Logotipo em variações de cor para marca de representações.', color: 'linear-gradient(150deg,#332030,#1c1e25)', img: 'assets/portfolio/eloa-logotipo.webp', fit: 'contain' },
  { type: 'Designer', cat: 'Logotipos', title: 'Rounds — Identidade Visual', desc: 'Logotipo para marca de streetwear inspirada em esportes de luta.', color: 'linear-gradient(150deg,#241414,#1c1e25)', img: 'assets/portfolio/rounds-logotipo.webp', fit: 'contain' },
  { type: 'Designer', cat: 'Mockups', title: 'Rounds — Mockup Vestuário', desc: 'Aplicação da marca em peça de vestuário.', color: 'linear-gradient(150deg,#1c1c1c,#1c1e25)', img: 'assets/portfolio/rounds-mockup.webp' },
  { type: 'Designer', cat: 'Ilustrações', title: 'Estudo de Olho', desc: 'Estudo de pintura digital realista.', color: 'linear-gradient(150deg,#1f2530,#1c1e25)', img: 'assets/portfolio/estudo-olho.webp' },
  { type: 'Designer', cat: 'Ilustrações', title: 'Estudo de Lábios', desc: 'Estudo de cor e luz em pintura digital.', color: 'linear-gradient(150deg,#302030,#1c1e25)', img: 'assets/portfolio/estudo-labios.webp' },
  { type: 'Web', cat: 'Web', title: 'Brasa Burger — Site & Cardápio', desc: 'Landing page e cardápio digital interativo para hamburgueria.', color: 'linear-gradient(150deg,#3a1710,#1c0f0b)', url: 'https://juicy-burger-experience.lovable.app/#cardapio' },
  { type: 'Social Media', cat: 'Social Media', title: 'Como Fazer uma Renda Extra com Design', desc: 'Carrossel educativo sobre carreira e oportunidades em design.', color: 'linear-gradient(150deg,#251a3a,#1c1e25)', img: 'assets/portfolio/renda-extra-carrossel.webp', fit: 'contain' },
  { type: 'Social Media', cat: 'Social Media', title: 'O Designer Gráfico Não Faz Mágica', desc: 'Carrossel sobre o processo e a estratégia por trás de cada criação.', color: 'linear-gradient(150deg,#3a1a24,#1c1e25)', img: 'assets/portfolio/nao-faz-magica.webp', fit: 'contain' },
  { type: 'Social Media', cat: 'Social Media', title: 'Morrer Para a Velha Vida', desc: 'Arte para conteúdo religioso sobre o simbolismo do batismo.', color: 'linear-gradient(150deg,#1a2420,#1c1e25)', img: 'assets/portfolio/morrer-velha-vida.webp' },
  { type: 'Social Media', cat: 'Social Media', title: 'Antes do Photoshop, Existe uma Ideia', desc: 'Peça conceitual sobre o processo criativo por trás de cada design.', color: 'linear-gradient(150deg,#241414,#1c1e25)', img: 'assets/portfolio/conceito-antes-da-ideia.webp' },
  { type: 'Social Media', cat: 'Social Media', title: 'Seu Design Fala Antes — Cena Épica', desc: 'Peça conceitual sobre a primeira impressão de uma marca.', color: 'linear-gradient(150deg,#1a2030,#1c1e25)', img: 'assets/portfolio/marca-fala-antes-01.webp' },
  { type: 'Social Media', cat: 'Social Media', title: 'Seu Design Fala Antes — Retrato', desc: 'Variação da peça conceitual em close, com foco no olhar.', color: 'linear-gradient(150deg,#1a2030,#1c1e25)', img: 'assets/portfolio/marca-fala-antes-02.webp' }
];

/* ---------- helpers de renderização compartilhados ---------- */
(function () {
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  // Conteúdo interno do card: imagem real, selo de link (site) ou placeholder.
  function frameContent(item) {
    if (item.img) return `<img src="${esc(item.img)}" alt="${esc(item.title)}" loading="lazy">`;
    if (item.url) return `<span style="font-family:var(--font-display);font-style:italic;font-size:1rem;">${esc(item.title)} ↗</span>`;
    return esc(item.title);
  }
  const frameClass = (item) => (item.fit === 'contain' ? ' contain' : '');
  const slidesBadge = (item) => (item.slides && item.slides.length > 1
    ? `<span class="slides-badge" aria-label="${item.slides.length} slides">${item.slides.length} slides</span>` : '');

  // Card do carrossel infinito da home
  window.marqueeCardHTML = function (item, index, clone) {
    const a = clone ? 'aria-hidden="true" tabindex="-1"' : 'role="button" tabindex="0"';
    return `<div class="marquee-card" ${a} data-index="${index}">
      <div class="ph${frameClass(item)}">${frameContent(item)}${slidesBadge(item)}</div>
      <div class="info"><span class="cat">${esc(item.cat)}</span><h4>${esc(item.title)}</h4></div>
    </div>`;
  };

  // Card da grade da página projetos.html
  window.projectCardHTML = function (item, index) {
    return `<button type="button" class="project-card" data-index="${index}" aria-label="Abrir ${esc(item.title)}">
      <div class="ph${frameClass(item)}">${frameContent(item)}${slidesBadge(item)}</div>
      <div class="info"><span class="cat">${esc(item.cat)}</span><h3>${esc(item.title)}</h3></div>
    </button>`;
  };
})();
