(function () {
    const TYPE_INFO = {
      'Designer':     { slug: 'designer',     desc: 'Logotipos, identidade visual, mockups e ilustrações digitais.' },
      'Social Media': { slug: 'social-media', desc: 'Posts, carrosséis e artes de divulgação para redes sociais.' },
      'Web':          { slug: 'web',          desc: 'Sites, landing pages e cardápios digitais.' }
    };
    const list = window.showcase;
    const root = document.getElementById('projects-root');
    const chips = document.getElementById('filter-chips');
    const types = window.PORTFOLIO_TYPES.filter(t => list.some(p => p.type === t));

    root.innerHTML = types.map(t => {
      const items = list.map((p, i) => ({ p, i })).filter(x => x.p.type === t);
      const info = TYPE_INFO[t] || { slug: t.toLowerCase().replace(/\s+/g, '-'), desc: '' };
      return `<div class="project-group" id="${info.slug}" data-type="${t}">
        <div class="group-head">
          <h2>${t}</h2>
          <p>${info.desc}</p>
          <span class="count">${items.length} ${items.length === 1 ? 'projeto' : 'projetos'}</span>
        </div>
        <div class="project-grid">${items.map(x => window.projectCardHTML(x.p, x.i)).join('')}</div>
      </div>`;
    }).join('');

    const chipDefs = [{ label: 'Todos', type: 'all', n: list.length }]
      .concat(types.map(t => ({ label: t, type: t, n: list.filter(p => p.type === t).length })));
    chips.innerHTML = chipDefs.map(c =>
      `<button type="button" class="chip" data-type="${c.type}">${c.label}<span class="n">${c.n}</span></button>`).join('');

    function applyFilter(type, pushHash) {
      chips.querySelectorAll('.chip').forEach(b => {
        const on = b.dataset.type === type;
        b.classList.toggle('active', on);
        b.setAttribute('aria-pressed', on ? 'true' : 'false');
      });
      root.querySelectorAll('.project-group').forEach(g => { g.hidden = !(type === 'all' || g.dataset.type === type); });
      if (pushHash) {
        const info = TYPE_INFO[type];
        history.replaceState(null, '', type === 'all' ? location.pathname : '#' + (info ? info.slug : ''));
      }
    }
    chips.addEventListener('click', (e) => {
      const b = e.target.closest('.chip');
      if (b) applyFilter(b.dataset.type, true);
    });

    // link direto: projetos.html#social-media abre já filtrado
    const slugToType = {};
    types.forEach(t => { slugToType[(TYPE_INFO[t] || {}).slug] = t; });
    const initial = slugToType[location.hash.replace('#', '')] || 'all';
    applyFilter(initial, false);
    window.addEventListener('hashchange', () => applyFilter(slugToType[location.hash.replace('#', '')] || 'all', false));

  })();
