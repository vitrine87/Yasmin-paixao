// Reflete o estado de login no header/sidebar (funciona tanto após o
  // redirect do Google quanto em qualquer visita normal com sessão ativa).
  (async () => {
    const session = await AuthService.getSession();
    if (!session) return;
    const name = (session.user.user_metadata && session.user.user_metadata.name) || session.user.email;
    const firstName = name.split(' ')[0];

    const navLink = document.getElementById('nav-login-link');
    if (navLink) {
      navLink.textContent = `Olá, ${firstName}`;
      navLink.href = '#';
      navLink.addEventListener('click', async (e) => {
        e.preventDefault();
        await AuthService.logout();
        window.location.reload();
      });
    }
    const sidebarLink = document.getElementById('sidebar-login-link');
    if (sidebarLink) {
      sidebarLink.textContent = `Sair (${firstName})`;
      sidebarLink.href = '#';
      sidebarLink.addEventListener('click', async (e) => {
        e.preventDefault();
        await AuthService.logout();
        window.location.reload();
      });
    }
  })();
