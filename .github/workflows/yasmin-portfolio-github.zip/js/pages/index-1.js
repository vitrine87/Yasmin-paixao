// dados de vitrine das ferramentas (stacks); os projetos ficam em js/portfolio-data.js — substituir por fetch ao Supabase Storage/DB.
  // Roda ANTES de main.js para que os elementos já existam quando o
  // DOMContentLoaded ligar os listeners de lightbox/stacks.
  const stacks = [
    { initials: 'Ps', name: 'Photoshop', title: 'Photoshop', desc: 'Edição, retoque e composição de imagens', featured: true },
    { initials: 'Ai', name: 'Illustrator', desc: 'Ilustração vetorial e logotipos' },
    { initials: 'Cd', name: 'CorelDRAW', desc: 'Diagramação para impressão' },
    { initials: 'Fg', name: 'Figma', desc: 'Prototipagem de interfaces' },
    { initials: 'Fr', name: 'Framer', desc: 'Protótipos interativos' },
    { initials: 'Ca', name: 'Canva', desc: 'Posts ágeis para redes sociais' },
    { initials: 'Ad', name: 'Adobe', desc: 'Fluxo Creative Cloud' },
  ];
  document.getElementById('keys-grid').innerHTML = stacks.map(s => {
    if (s.featured) {
      return `<button class="key featured">
        <div class="cap">
          <span class="glyph">${s.initials}</span>
          <span class="copy">
            <span class="title">${s.title}</span>
            <span class="label">${s.desc}</span>
          </span>
        </div>
      </button>`;
    }
    return `<button class="key"><div class="cap"><span class="glyph">${s.initials}</span><span class="label">${s.name}</span></div></button>`;
  }).join('');

  // divide a lista em duas fileiras intercaladas (índices pares/ímpares),
  // cada uma duplicada para o loop do carrossel ficar contínuo/sem emenda.
  const rowA = window.showcase.map((item, i) => ({ item, i })).filter(x => x.i % 2 === 0);
  const rowB = window.showcase.map((item, i) => ({ item, i })).filter(x => x.i % 2 === 1);
  const renderRow = (row) => row.map(x => window.marqueeCardHTML(x.item, x.i, false)).concat(row.map(x => window.marqueeCardHTML(x.item, x.i, true))).join('');
  document.getElementById('marquee-track-1').innerHTML = renderRow(rowA);
  document.getElementById('marquee-track-2').innerHTML = renderRow(rowB);
