document.querySelectorAll('[data-particles]').forEach((canvas) => {
    new ParticleBackground(canvas, { density: parseFloat(canvas.dataset.density || '1') });
  });

  // troca entre painéis login / cadastro / recuperar
  document.querySelectorAll('[data-switch]').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const target = link.dataset.switch;
      document.querySelectorAll('.auth-switch').forEach(p => p.classList.remove('active'));
      document.getElementById(`panel-${target}`).classList.add('active');
    });
  });

  // mostrar/ocultar senha
  document.querySelectorAll('.toggle-visibility').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = document.getElementById(btn.dataset.toggle);
      const isPw = input.type === 'password';
      input.type = isPw ? 'text' : 'password';
      btn.textContent = isPw ? 'ocultar' : 'mostrar';
    });
  });

  function showFeedback(el, type, message) {
    el.removeAttribute('style');
    el.className = `form-feedback show ${type}`;
    el.textContent = message;
  }

  // LOGIN
  document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const btn = form.querySelector('button[type="submit"]');
    const feedback = document.getElementById('login-feedback');
    const { email, password } = Object.fromEntries(new FormData(form).entries());

    btn.disabled = true; btn.textContent = 'Entrando...';
    try {
      await AuthService.login(email, password);
      showFeedback(feedback, 'success', 'Login realizado! Redirecionando...');
      setTimeout(() => window.location.href = 'index.html', 1000);
    } catch (err) {
      showFeedback(feedback, 'error', err.message);
    } finally {
      btn.disabled = false; btn.textContent = 'Entrar';
    }
  });

  document.getElementById('google-login').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    const feedback = document.getElementById('login-feedback');
    btn.disabled = true;
    const originalText = btn.innerHTML;
    btn.innerHTML = 'Redirecionando para o Google...';
    try {
      await AuthService.loginWithGoogle();
      // sucesso = a página já está navegando para o Google; nada mais a fazer aqui.
    } catch (err) {
      btn.disabled = false;
      btn.innerHTML = originalText;
      feedback.className = 'form-feedback show error';
      feedback.textContent = err.message;
    }
  });

  // CADASTRO
  document.getElementById('signup-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const btn = form.querySelector('button[type="submit"]');
    const feedback = document.getElementById('signup-feedback');
    const { name, email, password } = Object.fromEntries(new FormData(form).entries());

    btn.disabled = true; btn.textContent = 'Criando conta...';
    try {
      await AuthService.signup(name, email, password);
      showFeedback(feedback, 'success', 'Verifique seu e-mail para confirmar o cadastro. Depois é só entrar.');
      form.reset();
      setTimeout(() => document.querySelector('[data-switch="login"]').click(), 1200);
    } catch (err) {
      feedback.className = 'form-feedback show error';
      feedback.textContent = err.message;
    } finally {
      btn.disabled = false; btn.textContent = 'Criar conta';
    }
  });

  // RECUPERAR SENHA
  document.getElementById('recover-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const btn = form.querySelector('button[type="submit"]');
    const feedback = document.getElementById('recover-feedback');
    const { email } = Object.fromEntries(new FormData(form).entries());

    if (!email || !email.trim()) { showFeedback(feedback, 'error', 'Informe seu e-mail.'); return; }
    btn.disabled = true; btn.textContent = 'Enviando...';
    try {
      await AuthService.recoverPassword(email);
      showFeedback(feedback, 'success', 'Se existir uma conta para este e-mail, um link de recuperação foi enviado.');
    } catch (err) {
      showFeedback(feedback, 'error', err.message);
    } finally {
      btn.disabled = false; btn.textContent = 'Enviar link';
    }
  });

  // link de recuperação: o Supabase dispara PASSWORD_RECOVERY ao voltar para esta página
  if (window.YP && window.YP.db) {
    window.YP.db.auth.onAuthStateChange((event) => {
      if (event === 'PASSWORD_RECOVERY') {
        document.querySelectorAll('.auth-switch').forEach(p => p.classList.remove('active'));
        document.getElementById('panel-reset').classList.add('active');
      }
    });
  }
  document.getElementById('reset-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    const feedback = document.getElementById('reset-feedback');
    const password = e.target.password.value;
    if (password.length < 8) { showFeedback(feedback, 'error', 'A senha precisa ter pelo menos 8 caracteres.'); return; }
    btn.disabled = true;
    try {
      await AuthService.updatePassword(password);
      showFeedback(feedback, 'success', 'Senha atualizada! Redirecionando...');
      setTimeout(() => window.location.href = 'index.html', 1200);
    } catch (err) {
      showFeedback(feedback, 'error', err.message);
      btn.disabled = false;
    }
  });
