/* Painel admin — só textContent/DOM (nunca innerHTML com dados de visitantes). Acesso real é garantido por RLS + MFA no banco. */
(async () => {
  const db = window.YP && window.YP.db;
  const $ = (id) => document.getElementById(id);
  const views = ['view-msg', 'view-mfa', 'view-list'];
  const show = (id) => views.forEach((v) => { $(v).hidden = v !== id; });
  const say = (t) => { $('msg-text').textContent = t; show('view-msg'); };
  const STATUS = { pending: 'Em análise', confirmed: 'Confirmado', refused: 'Recusado' };
  const el = (tag, props = {}, ...kids) => { const n = document.createElement(tag); Object.assign(n, props); n.append(...kids); return n; };

  if (!db) return say('Serviço indisponível no momento.');
  $('btn-logout').addEventListener('click', async () => { await db.auth.signOut(); location.href = 'login.html'; });

  const { data: { session } } = await db.auth.getSession();
  if (!session) { location.href = 'login.html'; return; }
  const { data: isAdmin } = await db.rpc('is_admin');
  if (!isAdmin) return say('Esta conta não tem acesso ao painel.');

  async function ensureMfa() {
    const { data: aal } = await db.auth.mfa.getAuthenticatorAssuranceLevel();
    if (aal.currentLevel === 'aal2') return;
    show('view-mfa');
    const { data: f } = await db.auth.mfa.listFactors();
    let factorId = f.totp && f.totp[0] && f.totp[0].id; // só fatores já verificados
    if (!factorId) {
      const { data, error } = await db.auth.mfa.enroll({ factorType: 'totp', friendlyName: 'Painel ' + Date.now() });
      if (error) throw error;
      factorId = data.id;
      $('mfa-qr').src = data.totp.qr_code;
      $('mfa-secret').textContent = data.totp.secret;
      $('mfa-enroll').hidden = false;
    }
    await new Promise((resolve) => {
      $('mfa-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const ch = await db.auth.mfa.challenge({ factorId });
        const v = ch.error ? ch : await db.auth.mfa.verify({ factorId, challengeId: ch.data.id, code: $('mfa-code').value.trim() });
        if (v.error) { $('mfa-error').textContent = 'Código inválido. Tente novamente.'; return; }
        resolve();
      });
    });
  }

  let rows = [];
  async function load() {
    const { data, error } = await db.from('quote_requests').select('*').order('created_at', { ascending: false }).limit(200);
    if (error) { $('list').textContent = 'Não foi possível carregar os pedidos.'; return; }
    rows = data; render();
  }

  function render() {
    const f = $('filter').value, list = $('list');
    list.replaceChildren();
    const shown = rows.filter((r) => !f || r.status === f);
    $('count').textContent = shown.length + ' pedido(s)';
    shown.forEach((r) => {
      const digits = String(r.phone).replace(/\D/g, '');
      const wa = 'https://wa.me/' + (digits.length <= 11 ? '55' + digits : digits);
      const sel = el('select', { 'aria-label': 'Status' });
      Object.entries(STATUS).forEach(([k, v]) => sel.append(el('option', { value: k, textContent: v, selected: k === r.status })));
      const note = el('textarea', { value: r.admin_message || '', placeholder: 'Mensagem para o cliente (aparece na consulta)' });
      const fb = el('span', { role: 'status' });
      const save = el('button', { className: 'btn btn-primary', type: 'button', textContent: 'Salvar' });
      const del = el('button', { className: 'btn btn-outline', type: 'button', textContent: 'Excluir' });
      save.addEventListener('click', async () => {
        save.disabled = true;
        const msg = note.value.trim() || null;
        const { error } = await db.from('quote_requests').update({ status: sel.value, admin_message: msg }).eq('tracking_code', r.tracking_code);
        fb.textContent = error ? 'Erro ao salvar.' : 'Salvo ✓';
        if (!error) { r.status = sel.value; r.admin_message = msg; }
        save.disabled = false;
      });
      del.addEventListener('click', async () => {
        if (!confirm('Excluir definitivamente o pedido ' + r.tracking_code + '?')) return;
        const { error } = await db.from('quote_requests').delete().eq('tracking_code', r.tracking_code);
        if (error) { fb.textContent = 'Erro ao excluir.'; return; }
        rows = rows.filter((x) => x !== r); render();
      });
      list.append(el('article', { className: 'adm-card' },
        el('header', {}, el('strong', { textContent: r.tracking_code }), el('span', { textContent: ' · ' + new Date(r.created_at).toLocaleString('pt-BR') + ' · ' + r.service })),
        el('p', {}, el('b', { textContent: r.name + ' — ' }), el('a', { href: wa, target: '_blank', rel: 'noopener', textContent: r.phone })),
        el('p', { className: 'adm-msg', textContent: r.message }),
        sel, note, el('div', { className: 'adm-actions' }, save, del, fb)));
    });
  }

  $('filter').addEventListener('change', render);
  $('btn-refresh').addEventListener('click', load);
  try { await ensureMfa(); show('view-list'); await load(); } catch { say('Não foi possível iniciar o painel.'); }
})();
