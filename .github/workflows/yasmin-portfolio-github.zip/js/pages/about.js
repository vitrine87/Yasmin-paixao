/* Sobre — animações de scroll (só transform/opacity/clip-path). Sem animação com prefers-reduced-motion. */
(() => {
  const g = window.gsap, ST = window.ScrollTrigger, root = document.getElementById('sobre');
  if (!g || !ST || !root || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  g.registerPlugin(ST);
  const $ = (s) => root.querySelector(s);
  const name = $('.p-name');
  name.innerHTML = [...name.textContent.trim()].map((c) => '<span class="ch">' + c + '</span>').join('');
  name.setAttribute('aria-label', 'Yasmin');

  // PRAZER: título, nome em letras, texto e retrato
  g.timeline({ scrollTrigger: { trigger: '.prazer', start: 'top 72%', toggleActions: 'play none none none' } })
    .from('.p-kicker', { y: 16, opacity: 0, duration: .5 })
    .from('.p-line', { clipPath: 'inset(100% 0 0 0)', y: 26, duration: .8, ease: 'power4.out', stagger: .12 }, '<.1')
    .from('.p-name .ch', { yPercent: 55, opacity: 0, scale: .8, duration: .7, ease: 'back.out(1.6)', stagger: .06 }, '-=.4')
    .from('.p-body p, .prazer .about-tags', { y: 22, opacity: 0, duration: .6, stagger: .14 }, '-=.3');
  g.fromTo('.p-body strong', { color: '#2a2347' }, { color: '#6a22e0', stagger: .25, ease: 'none',
    scrollTrigger: { trigger: '.p-body', start: 'top 70%', end: 'bottom 45%', scrub: true } });
  g.fromTo('.prazer-photo img', { scale: 1.15, yPercent: 5 }, { scale: 1, yPercent: -3, ease: 'none',
    scrollTrigger: { trigger: '.prazer', start: 'top bottom', end: 'bottom top', scrub: true } });
  g.to('.p-glow', { yPercent: -35, ease: 'none', scrollTrigger: { trigger: '.prazer', start: 'top bottom', end: 'bottom top', scrub: true } });

  // QUEM SOU EU?: sequência ligada ao scroll + contador do selo
  const num = $('[data-count]'), c = { v: 0 };
  g.timeline({ scrollTrigger: { trigger: '.quem-stage', start: 'top 80%', end: 'bottom 60%', scrub: .6 } })
    .from('.quem-haze', { opacity: 0, scale: .8 })
    .from('.quem-small', { xPercent: -40, opacity: 0, rotate: -6 }, '<.1')
    .from('.quem-big', { yPercent: 12, opacity: 0, scale: 1.08 }, '<.1')
    .from('.q1', { xPercent: -25, opacity: 0, scale: 1.25 })
    .from('.q2', { yPercent: 40, opacity: 0, scale: 1.25 })
    .from('.q3', { xPercent: 25, opacity: 0, scale: 1.25 })
    .from('.quem-badge', { scale: .6, opacity: 0, y: 20 })
    .to(c, { v: 5, duration: .5, onUpdate: () => { num.textContent = Math.round(c.v); } }, '<');

  // inclinação leve com o mouse (só desktop)
  if (matchMedia('(hover:hover) and (pointer:fine)').matches) {
    const st = $('.quem-stage'), bx = g.quickTo('.quem-big', 'x', { duration: .6 }), sx = g.quickTo('.quem-small', 'x', { duration: .6 });
    st.addEventListener('pointermove', (e) => { const r = st.getBoundingClientRect(), k = (e.clientX - r.left) / r.width - .5; bx(k * 14); sx(k * -22); });
  }
})();
