const escHtml = (s) => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const statusConfig = {
    pending: { label: 'Pendente', cls: 'pending', message: 'Seu pedido está sendo analisado.' },
    confirmed: { label: 'Confirmada', cls: 'confirmed', message: 'Seu orçamento foi confirmado. Entre em contato pelo WhatsApp para os próximos passos.' },
    refused: { label: 'Recusada', cls: 'refused', message: 'Neste momento, não foi possível prosseguir com sua solicitação.' }
  };

  document.getElementById('status-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const btn = form.querySelector('button[type="submit"]');
    const errorBox = document.getElementById('status-error');
    const resultBox = document.getElementById('status-result');
    errorBox.classList.remove('show', 'error');
    resultBox.classList.remove('show');

    const { name, phone, trackingCode } = Object.fromEntries(new FormData(form).entries());

    btn.disabled = true; btn.textContent = 'Consultando...';
    let found = null;
    let failMessage = '';
    try {
      found = await window.QuotesService.consult({ name, phone, trackingCode });
    } catch (err) {
      failMessage = err.message;
    } finally {
      btn.disabled = false; btn.textContent = 'Consultar status';
    }

    if (!found) {
      errorBox.classList.add('show', 'error');
      errorBox.textContent = failMessage ||
        'Não encontramos nenhuma solicitação com esses dados. Verifique as informações e tente novamente.';
      return;
    }

    const cfg = statusConfig[found.status] || statusConfig.pending;
    document.getElementById('status-badge-wrap').innerHTML =
      `<span class="status-badge ${cfg.cls}">● ${cfg.label}</span>`;
    document.getElementById('status-message').textContent = found.adminMessage || cfg.message;

    document.getElementById('status-timeline').innerHTML = `
      <div class="timeline-step done">
        <strong>Solicitação enviada</strong>
        <span>${new Date(found.createdAt).toLocaleString('pt-BR')} · ${escHtml(found.service)}</span>
      </div>
      <div class="timeline-step ${found.status !== 'pending' ? 'done' : 'current'}">
        <strong>Em análise</strong>
        <span>Sua solicitação está sendo avaliada</span>
      </div>
      <div class="timeline-step ${found.status === 'confirmed' || found.status === 'refused' ? 'done' : ''}">
        <strong>${cfg.label}</strong>
        <span>${cfg.message}</span>
      </div>
    `;

    resultBox.classList.add('show');
  });
