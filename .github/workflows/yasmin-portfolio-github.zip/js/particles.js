/**
 * ParticleBackground
 * ---------------------------------------------------------------------
 * Background de partículas conectadas (estilo "constellation network"),
 * na paleta da marca Yasmin Paixão. Reutilizável no Hero e no Login.
 *
 * Uso:
 *   const bg = new ParticleBackground(document.getElementById('particles'), {
 *     density: 1,        // 0.5 (leve) a 1.5 (denso)
 *     interactive: true, // reage ao mouse/touch
 *     colorA: '#C6579E',
 *     colorB: '#F2B8DE'
 * });
 *
 * Cuidados de performance / acessibilidade já embutidos:
 * - menos partículas em telas pequenas
 * - pausa quando a aba perde o foco ou o canvas sai da viewport
 * - respeita prefers-reduced-motion (fica estático/quase estático)
 */
class ParticleBackground {
  constructor(canvas, options = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.options = Object.assign({
      density: 1,
      interactive: true,
      colorA: '#B85C86',
      colorB: '#DBA6C2',
      lineColor: '219, 166, 194',
      maxLinkDist: 130,
      baseSpeed: 0.18
    }, options);

    this.particles = [];
    this.pointer = { x: null, y: null, active: false };
    this.running = false;
    this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    this._resize = this._resize.bind(this);
    this._loop = this._loop.bind(this);
    this._onPointerMove = this._onPointerMove.bind(this);
    this._onPointerLeave = this._onPointerLeave.bind(this);
    this._onVisibility = this._onVisibility.bind(this);

    this._init();
  }

  _init() {
    this._resize();
    window.addEventListener('resize', this._resize, { passive: true });

    if (this.options.interactive) {
      this.canvas.addEventListener('mousemove', this._onPointerMove, { passive: true });
      this.canvas.addEventListener('mouseleave', this._onPointerLeave, { passive: true });
      this.canvas.addEventListener('touchmove', this._onPointerMove, { passive: true });
      this.canvas.addEventListener('touchend', this._onPointerLeave, { passive: true });
    }

    document.addEventListener('visibilitychange', this._onVisibility);

    this._observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) this.start();
        else this.stop();
      });
    }, { threshold: 0.05 });
    this._observer.observe(this.canvas);

    if (this.reducedMotion) {
      // versão praticamente estática: desenha um único frame calmo
      this.options.baseSpeed = 0.02;
    }
  }

  _resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = this.canvas.getBoundingClientRect();
    this.width = rect.width;
    this.height = rect.height;
    this.canvas.width = rect.width * dpr;
    this.canvas.height = rect.height * dpr;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this._buildParticles();
  }

  _buildParticles() {
    const area = this.width * this.height;
    // densidade responsiva: menos pontos em telas pequenas
    const base = window.innerWidth < 640 ? 9000 : 6500;
    const count = Math.min(140, Math.max(24, Math.floor((area / base) * this.options.density)));

    this.particles = new Array(count).fill(0).map(() => ({
      x: Math.random() * this.width,
      y: Math.random() * this.height,
      vx: (Math.random() - 0.5) * this.options.baseSpeed,
      vy: (Math.random() - 0.5) * this.options.baseSpeed,
      r: Math.random() * 1.6 + 0.6,
      tone: Math.random()
    }));
  }

  _onPointerMove(e) {
    const rect = this.canvas.getBoundingClientRect();
    const point = e.touches ? e.touches[0] : e;
    this.pointer.x = point.clientX - rect.left;
    this.pointer.y = point.clientY - rect.top;
    this.pointer.active = true;
  }

  _onPointerLeave() {
    this.pointer.active = false;
  }

  _onVisibility() {
    if (document.hidden) this.stop();
    else this.start();
  }

  start() {
    if (this.running) return;
    this.running = true;
    this._raf = requestAnimationFrame(this._loop);
  }

  stop() {
    this.running = false;
    if (this._raf) cancelAnimationFrame(this._raf);
  }

  _loop() {
    if (!this.running) return;
    this._tick();
    this._raf = requestAnimationFrame(this._loop);
  }

  _tick() {
    const { ctx, width, height, particles, options, pointer } = this;
    ctx.clearRect(0, 0, width, height);

    for (let p of particles) {
      p.x += p.vx;
      p.y += p.vy;

      if (p.x < 0 || p.x > width) p.vx *= -1;
      if (p.y < 0 || p.y > height) p.vy *= -1;

      if (options.interactive && pointer.active) {
        const dx = p.x - pointer.x;
        const dy = p.y - pointer.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const radius = 120;
        if (dist < radius) {
          const force = (1 - dist / radius) * 0.6;
          p.x += (dx / (dist || 1)) * force;
          p.y += (dy / (dist || 1)) * force;
        }
      }
    }

    // conexões entre partículas próximas
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const a = particles[i];
        const b = particles[j];
        const dx = a.x - b.x;
        const dy = a.y - b.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < options.maxLinkDist) {
          const alpha = (1 - dist / options.maxLinkDist) * 0.35;
          ctx.strokeStyle = `rgba(${options.lineColor}, ${alpha})`;
          ctx.lineWidth = 0.6;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
          ctx.stroke();
        }
      }
    }

    // conexão extra com o ponteiro (sensação de "rede" reagindo ao usuário)
    if (options.interactive && pointer.active) {
      for (let p of particles) {
        const dx = p.x - pointer.x;
        const dy = p.y - pointer.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < options.maxLinkDist * 1.3) {
          const alpha = (1 - dist / (options.maxLinkDist * 1.3)) * 0.5;
          ctx.strokeStyle = `rgba(255, 220, 245, ${alpha})`;
          ctx.lineWidth = 0.7;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(pointer.x, pointer.y);
          ctx.stroke();
        }
      }
    }

    // pontos
    for (let p of particles) {
      const color = p.tone > 0.5 ? options.colorA : options.colorB;
      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.globalAlpha = 0.75;
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }
  }

  destroy() {
    this.stop();
    window.removeEventListener('resize', this._resize);
    document.removeEventListener('visibilitychange', this._onVisibility);
    if (this._observer) this._observer.disconnect();
  }
}

// expõe globalmente (uso sem bundler / sem npm)
window.ParticleBackground = ParticleBackground;
