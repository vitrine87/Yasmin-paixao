/**
 * QuotesService
 * ---------------------------------------------------------------------
 * Camada de acesso a dados das solicitações de orçamento — agora ligada
 * ao Supabase de verdade (antes era uma demonstração em localStorage).
 *
 * O visitante NÃO acessa a tabela diretamente. Ele só chama duas funções
 * do banco (definidas em supabase/schema.sql):
 *
 *   create_quote_request  → cria a solicitação e devolve o código YP-XXXXXX
 *   consult_quote_request → devolve o status, exigindo nome + telefone + código
 *
 * Se o Supabase não estiver disponível (SDK bloqueado/sem internet), este
 * serviço LANÇA erro em vez de fingir que enviou — assim ninguém acha que
 * o pedido chegou quando não chegou.
 *
 * A assinatura pública (create/consult) é a mesma de antes.
 */
const QuotesService = (() => {
  const client = () => {
    if (!window.YP || !window.YP.db) {
      throw new Error('Não foi possível conectar ao servidor agora. Verifique sua internet ou fale comigo pelo WhatsApp.');
    }
    return window.YP.db;
  };

  function friendlyError(error) {
    const msg = (error && error.message) || '';
    if (msg.includes('rate_limited'))
      return 'Muitas tentativas em pouco tempo. Aguarde alguns minutos e tente de novo.';
    if (msg.includes('invalid_input'))
      return 'Confira os dados informados (nome, telefone com DDD e mensagem) e tente de novo.';
    if (msg.includes('try_again'))
      return 'Não foi possível gerar o código agora. Tente novamente em instantes.';
    return 'Não foi possível concluir agora. Tente novamente ou fale comigo pelo WhatsApp.';
  }

  return {
    /**
     * Cria uma nova solicitação de orçamento.
     * @param {{name:string, phone:string, service:string, message:string}} payload
     * @returns {Promise<{trackingCode: string}>}
     */
    async create(payload) {
      const { data, error } = await client().rpc('create_quote_request', {
        p_name: payload.name,
        p_phone: payload.phone,
        p_service: payload.service,
        p_message: payload.message
      });
      if (error) throw new Error(friendlyError(error));
      return { trackingCode: data };
    },

    /**
     * Consulta uma solicitação pelo nome + telefone + código de rastreio.
     * Retorna null se não encontrar (mensagem genérica evita enumeração).
     * @returns {Promise<null | {status:string, adminMessage:string, createdAt:string, service:string}>}
     */
    async consult({ name, phone, trackingCode }) {
      const { data, error } = await client().rpc('consult_quote_request', {
        p_name: name,
        p_phone: phone,
        p_tracking_code: trackingCode
      });
      if (error) throw new Error(friendlyError(error));
      if (!data) return null;
      return {
        status: data.status,
        adminMessage: data.admin_message || '',
        createdAt: data.created_at,
        service: data.service
      };
    }
  };
})();

window.QuotesService = QuotesService;
