/**
 * Supabase Client — SDK vendorizado em js/vendor/supabase.js (versão fixa, ver VERSIONS.md).
 * A publishable key é pública por design (protegida por RLS). NUNCA coloque a service_role aqui.
 * Expõe window.YP.db (não sobrescreve mais o namespace global `supabase`).
 */
(function () {
  const SUPABASE_URL = 'https://kymxqccbrepxlrkowvjk.supabase.co';
  const SUPABASE_ANON_KEY = 'sb_publishable_yr6rHwgIHJfFeRCLjTDsbA_MssJxu5E';
  window.YP = window.YP || {};
  if (window.supabase && typeof window.supabase.createClient === 'function') {
    window.YP.db = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, { auth: { flowType: 'pkce' } });
  } else {
    console.error('[Supabase] SDK não carregou — login e orçamentos indisponíveis.');
  }
})();
