/** AuthService — Supabase Auth. Sem modo demo: se o SDK não carregar, falha de forma explícita. */
const AuthService = (() => {
  const db = () => {
    if (!window.YP || !window.YP.db) throw new Error('Serviço indisponível no momento. Tente novamente em instantes.');
    return window.YP.db;
  };
  const page = (name) => new URL(name, window.location.href).href; // funciona em subpasta e URL limpa

  function traduzErro(error) {
    const msg = (error && error.message) || '';
    if (msg.includes('Invalid login credentials')) return 'E-mail ou senha inválidos.';
    if (msg.includes('Password should be at least')) return 'A senha precisa ter pelo menos 8 caracteres.';
    if (msg.includes('rate limit')) return 'Muitas tentativas. Aguarde um momento e tente de novo.';
    return 'Não foi possível completar a ação. Tente novamente.';
  }
  const wrap = async (promise) => {
    const { data, error } = await promise;
    if (error) throw new Error(traduzErro(error));
    return data;
  };

  return {
    async login(email, password) {
      return (await wrap(db().auth.signInWithPassword({ email: email.trim(), password }))).user;
    },
    // Resposta sempre genérica: não revela se o e-mail já existe.
    async signup(name, email, password) {
      const data = await wrap(db().auth.signUp({
        email: email.trim(), password,
        options: { data: { name: name.trim() }, emailRedirectTo: page('index.html') }
      }));
      return { needsConfirmation: !data.session };
    },
    async loginWithGoogle() {
      await wrap(db().auth.signInWithOAuth({ provider: 'google', options: { redirectTo: page('index.html') } }));
    },
    async recoverPassword(email) {
      await wrap(db().auth.resetPasswordForEmail(email.trim(), { redirectTo: page('login.html') }));
      return { sent: true };
    },
    async updatePassword(password) { await wrap(db().auth.updateUser({ password })); },
    async getSession() {
      try { const { data } = await db().auth.getSession(); return data.session; } catch { return null; }
    },
    async logout() { try { await db().auth.signOut(); } catch { /* ignora */ } }
  };
})();
window.AuthService = AuthService;
