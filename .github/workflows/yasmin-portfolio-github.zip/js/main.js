document.addEventListener('DOMContentLoaded', () => {

  const hasGSAP = typeof window.gsap !== 'undefined';
  if (hasGSAP && window.ScrollTrigger) {
    gsap.registerPlugin(ScrollTrigger);
  }
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- ACESSIBILIDADE: foco em modais + cards do carrossel via teclado ---------- */
  let lastFocus = null;
  const openModalFocus = (m) => {
    if (!m.classList.contains('open')) lastFocus = document.activeElement;
    setTimeout(() => (m.querySelector('.modal-close') || m).focus(), 30);
  };
  const closeModalFocus = () => { if (lastFocus && lastFocus.focus) lastFocus.focus(); };
  document.addEventListener('keydown', (e) => {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('.marquee-card')) {
      e.preventDefault(); e.target.click(); return;
    }
    if (e.key !== 'Tab') return;
    const open = document.querySelector('.modal-overlay.open');
    if (!open) return;
    const f = Array.from(open.querySelectorAll('a[href],button:not([disabled]),input,select,textarea')).filter(el => el.offsetParent !== null);
    if (!f.length) return;
    if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
    else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
  });

  /* ---------- HEADER SCROLL ---------- */
  const header = document.querySelector('.site-header');
  if (header) {
    const onScroll = () => header.classList.toggle('scrolled', window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  /* ---------- SIDEBAR (menu mobile) ---------- */
  const hamburger = document.querySelector('.hamburger');
  const sidebar = document.querySelector('.mobile-sidebar');
  const sidebarOverlay = document.querySelector('.sidebar-overlay');
  const sidebarClose = document.querySelector('.sidebar-close');

  function openSidebar() {
    hamburger.classList.add('open');
    hamburger.setAttribute('aria-expanded', 'true');
    sidebar.inert = false;
    sidebar.classList.add('open');
    sidebarOverlay.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeSidebar() {
    hamburger.classList.remove('open');
    hamburger.setAttribute('aria-expanded', 'false');
    sidebar.inert = true;
    sidebar.classList.remove('open');
    sidebarOverlay.classList.remove('open');
    document.body.style.overflow = '';
  }
  if (hamburger && sidebar) {
    sidebar.inert = true;
    hamburger.addEventListener('click', () => {
      sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
    });
    sidebarClose && sidebarClose.addEventListener('click', closeSidebar);
    sidebarOverlay && sidebarOverlay.addEventListener('click', closeSidebar);
    sidebar.querySelectorAll('a').forEach(a => a.addEventListener('click', closeSidebar));
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && sidebar.classList.contains('open')) closeSidebar();
    });
  }

  /* ---------- HERO ENTRANCE (aguarda o vídeo de logo terminar) ---------- */
  const heroSelectors = ['.hero-eyebrow', '.hero-title', '.hero-sub', '.hero-actions'];
  const heroVideo = document.querySelector('.hero-video');

  function playHeroEntrance() {
    if (hasGSAP && !prefersReducedMotion) {
      gsap.timeline({ defaults: { ease: 'power3.out' } })
        .to(heroSelectors, {
          opacity: 1,
          y: 0,
          duration: 0.9,
          stagger: 0.16
        }, 0);
    } else {
      // fallback sem GSAP / respeitando reduced motion
      heroSelectors.forEach(sel => {
        const el = document.querySelector(sel);
        if (el) { el.style.opacity = '1'; el.style.transform = 'none'; }
      });
    }
  }

  if (heroVideo && !prefersReducedMotion) {
    // some navegadores já disparam "ended" antes do listener ser anexado
    // (vídeo muito curto/cache) — cobrimos os dois casos.
    let entranceStarted = false;
    const startOnce = () => {
      if (entranceStarted) return;
      entranceStarted = true;
      playHeroEntrance();
    };
    heroVideo.addEventListener('ended', startOnce);
    // salvaguarda: se o vídeo não carregar/tocar por qualquer motivo
    // (autoplay bloqueado, conexão lenta, etc.), o texto aparece mesmo assim.
    setTimeout(startOnce, 7000);
    if (heroVideo.ended) startOnce();
  } else {
    // reduced-motion: nem tenta animar o vídeo — troca o poster para o
    // frame final (logo completa) e mostra isso parado, sem esperar.
    if (heroVideo) {
      heroVideo.removeAttribute('autoplay');
      heroVideo.pause();
      heroVideo.setAttribute('poster', 'assets/video/hero-logo-reveal-poster-end.jpg');
    }
    playHeroEntrance();
  }

  /* ---------- SCROLL REVEAL ---------- */
  const revealEls = document.querySelectorAll('.reveal');
  if (hasGSAP && window.ScrollTrigger && !prefersReducedMotion) {
    revealEls.forEach(el => {
      // Se o bloco contém eyebrow/título/lead, anima em cascata (mais
      // premium); senão, anima o bloco inteiro de uma vez.
      const introParts = el.querySelectorAll(':scope > .eyebrow, :scope > .section-title, :scope > .section-lead');
      const targets = introParts.length ? Array.from(introParts) : [el];
      // Quando quem anima são os filhos, o próprio elemento .reveal precisa
      // sair do opacity:0 do CSS imediatamente — senão ele continua
      // escondendo tudo dentro dele, mesmo com os filhos já visíveis.
      if (introParts.length) gsap.set(el, { opacity: 1, y: 0 });
      gsap.fromTo(targets, { opacity: 0, y: 26 }, {
        opacity: 1, y: 0, duration: 0.8, ease: 'power2.out', stagger: 0.12,
        scrollTrigger: { trigger: el, start: 'top 88%' }
      });
    });

    // Entrada em cascata para grades de cards (galeria e teclas de stacks)
    const batchReveal = (selector, opts = {}) => {
      const targets = gsap.utils.toArray(selector);
      if (!targets.length) return;
      gsap.set(targets, { opacity: 0, y: opts.y ?? 24, scale: opts.scale ?? 0.97 });
      ScrollTrigger.batch(targets, {
        start: 'top 92%',
        onEnter: batch => gsap.to(batch, {
          opacity: 1, y: 0, scale: 1,
          duration: opts.duration ?? 0.6,
          stagger: opts.stagger ?? 0.08,
          ease: opts.ease ?? 'power2.out'
        }),
        once: true
      });
    };
    batchReveal('.key', { y: 14, scale: 0.85, duration: 0.5, stagger: 0.06, ease: 'back.out(1.7)' });

    // Logo do header: leve entrada ao carregar a página
    gsap.fromTo('.site-header .brand img', { opacity: 0, scale: 0.9, filter: 'blur(4px)' },
      { opacity: 1, scale: 1, filter: 'blur(0px)', duration: 0.8, ease: 'power2.out', delay: 0.1 });
  } else if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    revealEls.forEach(el => io.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add('in-view'));
  }

  /* ---------- TECLAS (STACKS): toque em telas sem hover ---------- */
  // Espelha o :hover em telas de toque com uma classe, disparada no toque
  // em vez de no ponteiro do mouse.
  document.querySelectorAll('.key').forEach((key) => {
    key.addEventListener('touchstart', () => key.classList.add('is-active'), { passive: true });
    key.addEventListener('touchend', () => {
      setTimeout(() => key.classList.remove('is-active'), 260);
    });
    key.addEventListener('click', (e) => e.currentTarget.blur());
  });

  /* ---------- STICKY STACK: sobreposição com leve profundidade no scroll ---------- */
  document.querySelectorAll('.stack-scroll').forEach((scrollGroup) => {
    const stickyCards = scrollGroup.querySelectorAll('.stack-card-sticky');
    if (!hasGSAP || !window.ScrollTrigger || prefersReducedMotion || !stickyCards.length) return;
    const stickyTop = getComputedStyle(stickyCards[0]).top || '92px';
    const restShadow = 'drop-shadow(0 20px 40px rgba(0,0,0,0.35))';
    stickyCards.forEach((card, i) => {
      if (i === stickyCards.length - 1) return; // o último não precisa encolher
      gsap.fromTo(card,
        { scale: 1, filter: `brightness(1) ${restShadow}` },
        {
          scale: 0.94,
          filter: `brightness(0.7) ${restShadow}`,
          ease: 'none',
          scrollTrigger: {
            trigger: card,
            start: `top ${stickyTop}`,
            endTrigger: stickyCards[i + 1],
            end: `top ${stickyTop}`,
            scrub: true
          }
        }
      );
    });
  });

  /* ---------- WHATSAPP FLOAT ---------- */
  const waFloat = document.querySelector('.whatsapp-float');
  if (waFloat) {
    setTimeout(() => waFloat.classList.add('show'), 1000);
  }

  /* ---------- FAQ ACCORDION ---------- */
  document.querySelectorAll('.faq-item').forEach(item => {
    const q = item.querySelector('.faq-q');
    q.addEventListener('click', () => {
      const wasOpen = item.classList.contains('open');
      item.parentElement.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
      if (!wasOpen) item.classList.add('open');
    });
  });

  /* ---------- LIGHTBOX (a partir de window.showcase, por índice) ----------
     Serve a home (carrosséis) e a página projetos.html (grade por tipo).
     Suporta projetos com vários slides (item.slides) e proporção própria
     (item.ratio) para não cortar posts verticais. */
  const lightbox = document.getElementById('lightbox');
  if (lightbox && Array.isArray(window.showcase)) {
    const lbImage = lightbox.querySelector('.lb-image');
    const lbTitle = lightbox.querySelector('.lb-title');
    const lbCat = lightbox.querySelector('.lb-cat');
    const lbDesc = lightbox.querySelector('.lb-desc');
    const lbVisit = lightbox.querySelector('.lb-visit');
    const list = window.showcase;
    let currentIndex = 0;
    let slideIndex = 0;

    const escAttr = (v) => String(v == null ? '' : v).replace(/"/g, '&quot;');
    const slidesOf = (item) => (item.slides && item.slides.length ? item.slides : (item.img ? [item.img] : []));

    const sizeFrame = (item) => {
      lbImage.style.position = 'relative';
      if (item.ratio) {
        const [w, h] = String(item.ratio).split('/').map(Number);
        const r = (w && h) ? w / h : 4 / 3;
        lbImage.style.aspectRatio = item.ratio;
        lbImage.style.width = `min(100%, calc(min(64vh, 560px) * ${r}))`;
        lbImage.style.margin = '0 auto 18px';
      } else {
        lbImage.style.aspectRatio = '4/3';
        lbImage.style.width = '';
        lbImage.style.margin = '0 0 18px';
      }
    };

    const renderImage = (item) => {
      const slides = slidesOf(item);
      const fit = item.fit === 'contain' ? 'contain' : 'cover';
      lbImage.style.background = fit === 'contain'
        ? 'linear-gradient(160deg, var(--bg-elevated), var(--bg-card-hover))'
        : 'none';
      const padding = fit === 'contain' ? 'padding:24px;' : '';
      const multi = slides.length > 1;
      lbImage.innerHTML =
        `<img src="${escAttr(slides[slideIndex])}" alt="${escAttr(item.title)}${multi ? ' — slide ' + (slideIndex + 1) : ''}" style="width:100%;height:100%;object-fit:${fit};${padding}box-sizing:border-box;">` +
        (multi
          ? `<button type="button" class="lb-slide lb-slide-prev" aria-label="Slide anterior">&#8249;</button>
             <button type="button" class="lb-slide lb-slide-next" aria-label="Próximo slide">&#8250;</button>
             <span class="lb-slide-count">${slideIndex + 1}/${slides.length}</span>`
          : '');
    };

    const openLightbox = (index) => {
      currentIndex = (index + list.length) % list.length;
      slideIndex = 0;
      const item = list[currentIndex];
      lbTitle.textContent = item.title || '';
      lbCat.textContent = item.cat || '';
      lbDesc.textContent = item.desc || '';
      sizeFrame(item);
      if (slidesOf(item).length) {
        renderImage(item);
      } else {
        lbImage.innerHTML = '';
        lbImage.style.background = item.color || 'var(--bg-elevated)';
        lbImage.textContent = item.title || '';
      }
      if (item.url && /^https?:\/\//i.test(item.url)) {
        lbVisit.href = item.url;
        lbVisit.style.display = 'inline-flex';
      } else {
        lbVisit.style.display = 'none';
      }
      openModalFocus(lightbox);
      lightbox.classList.add('open');
      document.body.style.overflow = 'hidden';
    };

    const moveSlide = (delta) => {
      const item = list[currentIndex];
      const total = slidesOf(item).length;
      if (total < 2) return false;
      slideIndex = (slideIndex + delta + total) % total;
      renderImage(item);
      return true;
    };

    // delegação de evento: cobre os cards originais, as cópias duplicadas do
    // carrossel infinito e os cards da grade de projetos.
    document.addEventListener('click', (e) => {
      const card = e.target.closest('.marquee-card, .project-card');
      if (!card) return;
      openLightbox(parseInt(card.dataset.index, 10) || 0);
    });

    const closeLightbox = () => {
      lightbox.classList.remove('open');
      document.body.style.overflow = '';
      closeModalFocus();
    };

    lightbox.querySelector('.modal-close').addEventListener('click', closeLightbox);
    lightbox.addEventListener('click', (e) => {
      if (e.target === lightbox) { closeLightbox(); return; }
      const slideBtn = e.target.closest('.lb-slide');
      if (slideBtn) moveSlide(slideBtn.classList.contains('lb-slide-prev') ? -1 : 1);
    });
    lightbox.querySelector('.lb-prev').addEventListener('click', () => openLightbox(currentIndex - 1));
    lightbox.querySelector('.lb-next').addEventListener('click', () => openLightbox(currentIndex + 1));

    document.addEventListener('keydown', (e) => {
      if (!lightbox.classList.contains('open')) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowRight' && !moveSlide(1)) openLightbox(currentIndex + 1);
      if (e.key === 'ArrowLeft' && !moveSlide(-1)) openLightbox(currentIndex - 1);
    });

    // toque: deslizar para os lados troca de slide (ou de projeto, se não houver slides)
    let touchX = null;
    lbImage.addEventListener('touchstart', (e) => { touchX = e.touches[0].clientX; }, { passive: true });
    lbImage.addEventListener('touchend', (e) => {
      if (touchX === null) return;
      const dx = e.changedTouches[0].clientX - touchX;
      touchX = null;
      if (Math.abs(dx) < 50) return;
      const dir = dx < 0 ? 1 : -1;
      if (!moveSlide(dir)) openLightbox(currentIndex + dir);
    }, { passive: true });
  }

  /* ---------- MODAL DE ORÇAMENTO ---------- */
  const quoteModal = document.getElementById('quote-modal');
  const openers = document.querySelectorAll('[data-open-quote]');
  if (quoteModal) {
    const closeBtn = quoteModal.querySelector('.modal-close');
    const openQuote = (service) => {
      const fb = quoteModal.querySelector('.form-feedback');
      if (fb) { fb.className = 'form-feedback'; fb.textContent = ''; }
      openModalFocus(quoteModal);
      quoteModal.classList.add('open');
      document.body.style.overflow = 'hidden';
      if (service) {
        const select = quoteModal.querySelector('#quote-service');
        if (select) select.value = service;
      }
    };
    const closeQuote = () => {
      quoteModal.classList.remove('open');
      document.body.style.overflow = '';
      closeModalFocus();
    };
    openers.forEach(btn => btn.addEventListener('click', () => openQuote(btn.dataset.service)));
    if (new URLSearchParams(location.search).has('orcamento')) openQuote();
    closeBtn.addEventListener('click', closeQuote);
    quoteModal.addEventListener('click', (e) => { if (e.target === quoteModal) closeQuote(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && quoteModal.classList.contains('open')) closeQuote(); });

    /* validação + envio real via Supabase (ver services/quotes.js) */
    const form = quoteModal.querySelector('#quote-form');
    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        let valid = true;
        if (form.elements.website && form.elements.website.value) return; // honeypot anti-bot
        form.querySelectorAll('[required]').forEach(field => {
          const wrap = field.closest('.field');
          const bad = !field.value.trim() || (field.type === 'checkbox' && !field.checked) || (field.type === 'tel' && !/^\d{10,11}$/.test(field.value.replace(/\D/g, '')));
          if (bad) {
            wrap.classList.add('has-error');
            valid = false;
          } else {
            wrap.classList.remove('has-error');
          }
        });
        if (!valid) return;

        const submitBtn = form.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Enviando solicitação...';

        const data = Object.fromEntries(new FormData(form).entries());
        const feedback = quoteModal.querySelector('.form-feedback');
        feedback.classList.remove('show', 'success', 'error');

        try {
          const result = await window.QuotesService.create(data);
          feedback.classList.add('show', 'success');
          feedback.textContent = 'Solicitação enviada com sucesso! Guarde o código abaixo para consultar o andamento.';
          const code = document.createElement('div');
          code.className = 'form-feedback tracking-code show';
          code.textContent = result.trackingCode;
          const copy = document.createElement('button');
          copy.type = 'button'; copy.className = 'btn btn-outline btn-block'; copy.textContent = 'Copiar código';
          copy.addEventListener('click', async () => {
            try { await navigator.clipboard.writeText(result.trackingCode); copy.textContent = 'Copiado ✓'; }
            catch { copy.textContent = 'Selecione e copie o código acima'; }
          });
          feedback.append(code, copy);
          form.reset();
        } catch (err) {
          feedback.classList.add('show', 'error');
          feedback.textContent = err.message;
        } finally {
          submitBtn.disabled = false;
          submitBtn.textContent = 'Enviar solicitação';
        }
      });
    }
  }

  /* ---------- MÁSCARA DE TELEFONE (BR) ---------- */
  document.querySelectorAll('input[data-mask="phone"]').forEach(input => {
    input.addEventListener('input', () => {
      let v = input.value.replace(/\D/g, '').slice(0, 11);
      if (v.length > 6) v = v.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3');
      else if (v.length > 2) v = v.replace(/(\d{2})(\d{0,5})/, '($1) $2');
      input.value = v;
    });
  });


  // recalcula posições do ScrollTrigger depois que imagens/fontes carregarem
  window.addEventListener('load', () => { if (hasGSAP && window.ScrollTrigger) ScrollTrigger.refresh(); });

  // botão de pausa do carrossel
  const mToggle = document.querySelector('.marquee-toggle'), mRows = document.querySelector('.marquee-rows');
  if (mToggle && mRows) mToggle.addEventListener('click', () => {
    const p = mRows.classList.toggle('paused');
    mToggle.setAttribute('aria-pressed', String(p));
    mToggle.textContent = p ? 'Retomar carrossel' : 'Pausar carrossel';
  });
});
