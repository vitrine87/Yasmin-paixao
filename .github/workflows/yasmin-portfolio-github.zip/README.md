# Yasmin Paixão — Portfólio

Site estático (HTML/CSS/JS puro, sem build) + Supabase (orçamentos, login e painel). GSAP e supabase-js vendorizados em `js/vendor/` (versões em `VERSIONS.md`).

## Estrutura
```
index.html · projetos.html · consultar-solicitacao.html · login.html
admin.html (painel, exige login + MFA) · privacidade.html · 404.html
css/styles.css
js/main.js · js/portfolio-data.js · js/boot.js
js/services/   supabaseClient.js, auth.js, quotes.js
js/pages/      scripts de cada página (a CSP não aceita script inline)
js/vendor/     gsap, ScrollTrigger, supabase-js (não editar)
assets/        logo, icons, video, about, portfolio
supabase/      schema.sql + functions/notify-quote
docs/          adicionar-projetos.md, fontes/ (originais, não usados no site)
manifest.json · sitemap.xml · robots.txt · llms.txt · _headers · vercel.json
```

## Publicar no GitHub Pages
1. Crie o repositório e envie **o conteúdo** desta pasta na raiz (`index.html` na raiz, não dentro de subpasta).
   Arquivos que começam com ponto (`.nojekyll`, `.gitignore`) às vezes não sobem pelo celular/web; o site funciona sem eles.
2. Settings → Pages → Deploy from a branch → `main` / `(root)`.
3. Troque `SEU-DOMINIO-AQUI.com.br` pela URL final em todos os arquivos (canonical, og:image, sitemap, robots, llms.txt, JSON-LD).
4. Preencha os campos `[entre colchetes]` em `privacidade.html` e revise com um(a) advogado(a).

## Supabase (nesta ordem)
1. SQL Editor → rode `supabase/schema.sql`.
2. Authentication: ligar **Confirm email**; desligar cadastro público ou ativar CAPTCHA; habilitar MFA (TOTP);
   em URL Configuration, colocar a URL do site e `https://SEU-USUARIO.github.io/SEU-REPO/**` em Redirect URLs.
3. Criar o usuário admin (login.html) e rodar o `insert into admins` comentado no fim do `schema.sql`.
4. Abrir `admin.html`, cadastrar o autenticador (QR code). Sem MFA a API não devolve pedidos.
5. Aviso por e-mail (opcional): `supabase functions deploy notify-quote --no-verify-jwt`, definir os segredos listados no topo de
   `supabase/functions/notify-quote/index.ts` e criar um Database Webhook (INSERT em `quote_requests`) com o header `x-webhook-secret`.

## Regras do projeto
- A chave em `supabaseClient.js` é a *publishable* (pública por design). **Nunca** coloque a `service_role` no repositório.
- Não use `<script>` inline: a CSP (`_headers`, `vercel.json` e `<meta>`) bloqueia. Crie um arquivo em `js/pages/`.
- Imagens novas em WebP (até ~1200 px). Como adicionar projetos: `docs/adicionar-projetos.md`.
